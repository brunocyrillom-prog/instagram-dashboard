export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(200).end();

  const TOKEN = process.env.IG_TOKEN;
  const IG_ID = process.env.IG_ID;

  if (!TOKEN || !IG_ID) {
    return res.status(500).json({ error: 'Variáveis de ambiente não configuradas' });
  }

  const { endpoint } = req.query;
  const BASE = 'https://graph.facebook.com/v18.0';

  try {
    let url;
    if (endpoint === 'profile') {
      url = `${BASE}/${IG_ID}?fields=name,username,followers_count,follows_count,media_count,biography,website,profile_picture_url&access_token=${TOKEN}`;
    } else if (endpoint === 'media') {
      url = `${BASE}/${IG_ID}/media?fields=id,caption,media_type,thumbnail_url,media_url,timestamp,like_count,comments_count,permalink&limit=12&access_token=${TOKEN}`;
    } else if (endpoint === 'insights') {
      url = `${BASE}/${IG_ID}/insights?metric=impressions,reach,profile_views,follower_count&period=day&since=${Math.floor(Date.now()/1000) - 7*86400}&until=${Math.floor(Date.now()/1000)}&access_token=${TOKEN}`;
    } else {
      return res.status(400).json({ error: 'Endpoint inválido' });
    }

    const response = await fetch(url);
    const data = await response.json();
    return res.status(200).json(data);
  } catch (e) {
    return res.status(500).json({ error: e.message });
  }
}
